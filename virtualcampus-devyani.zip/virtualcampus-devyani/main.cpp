#include <iostream>
#include "virtual_campus.h"

using namespace std;

int main()
{
    VirtualCampus vc();
    vc.start();
    return 0;
}

